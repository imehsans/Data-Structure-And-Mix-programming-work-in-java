/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectw;

import java.io.IOException;

/**
 *
 * @author khurram
 */
public class d {
    void run() throws IOException, ClassNotFoundException{
        MemClass l = new MemClass();
        l.print();
    }
}
